package HW7;

public interface MyList {
	public MyList next();
	public void printNode();
}
