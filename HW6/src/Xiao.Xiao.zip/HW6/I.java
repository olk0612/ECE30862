package HW6;

interface I {

   //public I( ) { }; // A: No constructor in interface

   int s = 0;
   int i = 1;

   void foo(short s); 

   void foo(int i); 

}
